# 25 Millennium Problem Proposals

**Project:** HUGIN
**Upstream:** https://github.com/nicedoc/hugin

Content specific to HUGIN in category CAMERAS.
