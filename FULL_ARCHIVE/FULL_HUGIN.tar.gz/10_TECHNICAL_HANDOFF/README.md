# 10 Technical Handoff

**Project:** HUGIN
**Upstream:** https://github.com/nicedoc/hugin

Content specific to HUGIN in category CAMERAS.
