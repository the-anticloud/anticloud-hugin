# OSINT Benchmark — HUGIN

**Upstream:** https://github.com/nicedoc/hugin

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: GPL
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
